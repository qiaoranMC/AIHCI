AIHCI v1.0正式发布啦！！！！！
目前自带了长期记忆模块，更多模块陆续开发中
如何编译？
第1步是要选择你的平台，目前支持安卓，other默认在相对路径下操作文件，接着创建以下文件方便程序操作:"ctrl","chat","input","output","hc","mem"，然后复制utils/utils.h到指定平台对应的目录
第2步在network_manger.c设置好api后端和key，使用以下命令开始编译
```bash
cd <平台>
gcc main_service.c -o ms
gcc network_manger.c -lcurl -o nm
gcc memory_module.c -o mm
gcc user_panel.c -o up
```
使用以下命令启动并运行AIHCI v1.0
```bash
./ms&
./nm&
./mm&
./up
```
如果一切没问题，你们会看到一个文字编辑界面，默认是命令模式，以下是具体用法：
返回键用于在命令/编辑模式间切换，mode的零和一值分别表示为命令/编辑模式
在处于命令模式下，h和l用于移动光标，g输入一个值后用于跳转光标位置，s是保存并发送

以上是AIHCI系统的所有基础用法，本项目将会长期维护下去，欢迎大家为本开源项目做出更多积极的贡献，喜欢的话记得给个star，这可是能让我继续开发和维护下去的动力！！！！！