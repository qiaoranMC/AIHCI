//AIHCI system main service
//The source file used with basic send user input and get ai output to save a file
//The program use GPLv3 license open source
//By qiaoran
//2025 (o) MC office
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"./utils.h"
#define max 10000000
#define mn 6
#define ml 255
#define sep 100000
char input[max],send[max],fn[mn][ml]={"./ctrl","./input","./mem","./chat","./output","./hc"};
int dsr(char *n){
	if(sr(sep,0,35,0,max,35,0,n,&input)!=0)return -1;
	return 0;
}
int main(){
	char *clp=&fn[0],*ip=&fn[1],*mp=&fn[2],*cp=&fn[3],*op=&fn[4],*hp=&fn[5];
	int a=0;
	for(a=0;a<max;a++){input[a]=0;send[a]=0;}
	for(a=0;a<mn;a++)osfc(1,0,35,fn[a]);
	while(1){
		if(ovfc(0,115,clp)!=0||ovfc(1,114,op)!=0||dsr(mp)!=0)continue;
		strcpy(send,input);
		if(dsr(cp)!=0)continue;
		strcat(send,input);
		cfd(op);
		if(ovw(0,35,35,0,ip,send)!=0||osfc(0,115,112,clp)!=0)continue;
	}
}