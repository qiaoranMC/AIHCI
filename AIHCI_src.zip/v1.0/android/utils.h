#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<conio.h>
#include<ctype.h>
FILE *fp;
int of(char *n,char m[2]){
	if((fp=fopen(n,m))==0)return -1;
	return 0;
}
int vh(int f){
	if(fgetc(fp)==f)return 0;
	return -1;
}
int ovfc(int c,int f,char *n){
	if(of(n,"r")!=0)return -1;
	if(c==0&&vh(f)!=0||c==1&&vh(f)==0){
		fclose(fp);
		return -2;
	}
	fclose(fp);
	return 0;
}
int ovf(int c,int f,char *n,char m[2]){
	if(ovfc(c,f,n)!=0)return -1;
	of(n,m);
	return 0;
}
int ef(int c,int f,char *n){
	if(ovf(c,f,n,"w")!=0)return -1;
	fclose(fp);
	return 0;
}
int sf(char f){
	fseek(fp,0,0);
	fputc(f,fp);
	return 0;
}
int ow(char *n,char *d){
	if(of(n,"w")!=0)return -1;
	fwrite(d,1,strlen(d),fp);
	fclose(fp);
	return 0;
}
int ovw(int m,int r,int f,char c,char *n,char *d){
	if(ovf(m,r,n,"w")!=0)return -1;
	sf(c);
	fwrite(d,1,strlen(d),fp);
	sf(f);
	fclose(fp);
	return 0;
}
int rf(int s,int ml,char *o){
	while(!feof(fp))
		if(s>=ml)break;
		else o[s++]=fgetc(fp);
	o[s-1]=0;
}
int or(int s,int ml,char *n,char *o){
	if(of(n,"r")!=0)return -1;
	rf(s,ml,o);
	fclose(fp);
	return 0;
}
int ovr(int m,int r,int s,int ml,int f,char c,char *n,char *o){
	if(ovf(m,r,n,"r+")!=0)return -1;
	sf(c);
	rf(s,ml,o);
	sf(f);
	fclose(fp);
	return 0;
}
int af(char *d){
	fseek(fp,0,2);
	fwrite(d,1,strlen(d),fp);
}
int oa(char *n,char *d){
	if(of(n,"a")!=0)return -1;
	af(d);
	fclose(fp);
	return 0;
}
int ova(int m,int r,int f,char c,char *n,char *d){
	if(ovf(m,r,n,"r+")!=0)return -1;
	sf(c);
	af(d);
	sf(f);
	fclose(fp);
	return 0;
}
int sw(int d,int m,int r,int f,char c,char *n,char *o){
	int a=d;
	while(a-->0)
		if(ovw(m,r,f,c,n,o)==0)break;
	if(a<0)return -1;
	return 0;
}
int sr(int d,int m,int r,int s,int ml,int f,char c,char *n,char *o){
	int a=d;
	while(a-->0)
		if(ovr(m,r,s,ml,f,c,n,o)==0)break;
	if(a<0)return -1;
	return 0;
}
int cf(int c,int f,char *n){
	if(ovf(c,f,n,"w")!=0)return -1;
	fclose(fp);
	return 0;
}
int cfd(char *n){
	return cf(1,-1,n);
}
int osf(int m,int r,int f,char *n){
	if(ovf(m,r,n,"r+")!=0)return -1;
	sf(f);
	return 0;
}
int osfc(int m,int r,int f,char *n){
	if(ovf(m,r,n,"r+")!=0)return -1;
	sf(f);
	fclose(fp);
	return 0;
}
int fs(int l,int s,int ml,int o,char *f,char *t){
	int a=0;
	l=s+l;
	while(a!=strlen(t)){
		if(s>l||s>ml||s<0||f[s]==91&&o==2||f[s]==0)return -1;
		else if(t[a]==f[s])a++;
		else a=0;s++;
	}
	if(o==0)return s;
	else return s-a;
}
int fc(int l,int s,int ml,char c,char *f){
	l=s+l;
	while(f[s]!=c)
		if(s>l||s>ml||s<0||f[s]==0)return -1;
		else s++;
	return s;
}
int gf(int l,int s,int ml,char c,char *n,char *f){
	while((s=fc(l,s,ml,c,f))>=0)
		if(fs(1,s-strlen(n),ml,0,f,n)>0)s+=strlen(n);
		else if(f[s]==c)return s;
	return -1;
}
int gna(int v,int l,int a,int ml,char *f,int *t){
	int b=0,c=0;
	char n[12];
	while(b<=v)
		if(c>l||c>12||a>ml||a<0||isdigit(n[c++]=f[a++])==0)return -1;
		else if(f[a]<48||f[a]>57){
			n[c]=0;c=0;a++;
			t[b++]=atoi(n);
		}
	return a-1;
}
int ga(int v,int l,int a,int ml,char *f,int *t){
	if((a=gna(v,l,a,ml,f,t))>0&&f[a]==93)return a;
	return -1;
}