//AIHCI user operation panel, the source program used with user input and ai output display
//2025 (O) MC office
#include"./utils.h"
#define max 100000
#define sep 100000
char input[max],output[max],cp[1000]="/sdcard/AIHCI/chat",op[1000]="/sdcard/AIHCI/output",clp[]="/sdcard/AIHCI/ctrl";
int ro(){
	while(ovfc(0,115,clp)==0);
	for(;;){
		if(sr(sep,0,35,0,max,35,0,op,&output)==0)return 0;
		puts("r:continue?(y/n)");
		if(getch()==110)return -1;
	}
}
int dfs(int s,int l,char *t){
	return fs(l,s,max,0,output,t);
}
int dga(int a,int v,int l,int *t){
	return ga(v,l,a,max,output,t);
}
int pa(int a){
	printf("%c",output[a]);
}
int po(){
	char ch[10];
	int a=0,b=0,n=0,o=0,p=0,q=0,out[10];
	for(a=0;a<10;a++){ch[a]=0;out[a]=0;}
	a=dfs(0,max,"content\":\"");
	if(a<=0)return -1;
	while(output[a]!=0){
		if((n=dfs(a,4,"[cmd "))>0){
			o=-1;p=0;q=0;
			if(dfs(n,5,"speed ")>0){
				if((o=dga(n+=6,0,5,&out))>0)b=out[0];
			}else if(dfs(n,4,"goto ")>0){
				if((o=dga(n+=5,1,4,&out))>0)gotoxy(out[0]+1,out[1]+1);
			}else if(dfs(n,3,"cxy ")>0){
				if((o=dga(n+=4,3,4,&out))>0)
					for(p=out[0];p<out[2];p++)
						for(q=out[1];q<out[3];q++){
							gotoxy(p,q);
							printf(" ");
						}
			}else if(dfs(n,5,"clear]")>0){
				o=n+5;
				clrscr();
			}else if(dfs(n,5,"getch]")>0){
				o=n+5;
				getch();
			}else if(dfs(n,2,"am ")>0||dfs(n,2,"dm ")>0){
				if((o=gf(1000,n+=3,max,93,"\\\\",output))>0)
					osfc(0,35,109,clp);
				for(p=0;p<sep/100;p++)
					if(ovfc(0,35,clp)==0)break;
			}
			if(o>=0)a=o;
			else pa(a);
		}else if(output[a]==92)
			if(output[++a]==110)printf("\n");
			else if(output[a]==34)printf("\"");
			else printf("\\%c",output[a]);
		else pa(a);
		usleep(b);
		if(dfs(++a,2,"\",\"")>0)break;
	}
}
int mt(int a,int c){
	input[a]=35;
	puts(input);
	input[a]=c;
}
int ics(int a,int b,char *f,char *t){
	while(f[a]!=0)
		t[b++]=f[a++];t[b]=0;
}
int iw(int a,int b,char c){
	ics(a,0,input,&output);
	input[a]=c;
	ics(0,a+=b,output,&input);
	return a;
}
int it(){
	int a=23,b=0;
	char c=0;
	while(!(c==115&&b==0)){
		puts(input);
		printf("locate:%d,mode:%d",a,b);
		c=getch();
		clrscr();
		if(a<0)a++;
		else if(a>=max)a--;
		if(c==27)
			if(b==0)b=1;
			else b=0;
		else if(c==127){
			a=iw(a,-1,0);
		}else if(b==0){
			if(c==104){
				c=input[--a];
				mt(a,c);
			}else if(c==108){
				c=input[++a];
				mt(a,c);
			}else if(c==103){
				scanf("%d",&a);
				if(a<0||a>=max)a=strlen(input);
			}
		}else if(b==1){
			a=iw(a,1,c);
		}
	}
	input[a]=0;
}
int main(){
	setbuf(stdout,0);
	for(int a=0;a<max;a++){input[a]=0;output[a]=0;}
	strcpy(input,"\n=====USER PROMPT=====\n");
	for(;;){
		it();
		sw(sep,0,35,35,0,cp,input);
		osfc(0,35,115,clp);
		if(ro()!=0)continue;
		po();
	}
}