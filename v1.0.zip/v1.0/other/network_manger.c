//AIHCI curl service
//by qiaoran
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<curl/curl.h>
#include"./utils.h"
#define mn 10000000
char clp[]="./ctrl",ip[]="./input",op[]="./output",hc[]="./hc",input[mn],ch=0;
int l[10];
int cat(int a,int l,char *s){
	input[a]=0;
	strcat(input,s);
	return a+l;
}
int da(){
	ova(1,0,35,0,hc,input);
}
int main(int argc,int **argv){
	for(int a=0;a<mn;a++)input[a]=0;
	int a=0,b=0;
	if(argv[1]==0)a=60;
	else a=atoi(argv[1]);
	CURL *curl;
	curl_global_init(CURL_GLOBAL_DEFAULT);
	curl=curl_easy_init();
	if(curl==0)return -1;
	curl_easy_setopt(curl,CURLOPT_URL,"http://127.0.0.1:8080/v1/chat/completions");
	curl_easy_setopt(curl,CURLOPT_TIMEOUT,a);
	if(argv[1]==0||argv[2]==0)a=1;
	else a=atoi(argv[2]);
	struct curl_slist *headers=NULL;
	headers=curl_slist_append(headers,"Authorization: Bearer 000000");
	headers=curl_slist_append(headers,"Content-Type: application/json");
	curl_easy_setopt(curl,CURLOPT_HTTPHEADER,headers);
	while(1){
		sleep(a);
		if(ovfc(0,112,clp)!=0||osf(0,35,0,ip)!=0)continue;
		strcpy(input,"{\"model\": \"Qwen/QwQ-32B\",\"messages\": [{\"role\": \"user\",\"content\": \"");
		b=strlen(input);
		while(!feof(fp))
			if((ch=fgetc(fp))==9)b=cat(b,2,"\\t");
			else if(ch==10)b=cat(b,2,"\\n");
			else if(ch==34)b=cat(b,2,"\\\"");
			else if(ch==92)b=cat(b,2,"\\\\");
			else input[b++]=ch;
		sf(35);
		fclose(fp);
		osfc(0,112,35,clp);
		input[b-1]=0;
		strcat(input,"\"}]}");
		input[b+3]=0;
		curl_easy_setopt(curl,CURLOPT_POSTFIELDS,input);
		of(op,"w");
		sf(0);
		curl_easy_setopt(curl,CURLOPT_WRITEDATA,fp);
		b=curl_easy_perform(curl);
		fclose(fp);
		if(b==CURLE_OPERATION_TIMEDOUT){
			printf("timeout\n");
			b=0;
			continue;
		}
		b=0;
		strcat(input,"\n");
		da();
		ovr(0,0,0,mn,35,0,op,&input);
		strcat(input,"\n");
		da();
	}
	curl_slist_free_all(headers);
	curl_easy_cleanup(curl);
	curl_global_cleanup();
}