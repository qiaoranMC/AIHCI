//AIHCI memory module
//This a large memory module, agent will operation this module to memory edit
//By:qiaoran
#include"./utils.h"
#define max 100000
#define sep 1000
#define mm 1000
#define ms 1000
char output[max],memory[mm][ms],op[]="/sdcard/AIHCI/output",mp[]="/sdcard/AIHCI/mem",clp[]="/sdcard/AIHCI/ctrl";
int rm(){
	int a=0,b=0;
	char ch;
	osf(0,35,0,mp);
	while(!feof(fp))
		if(a>=mm)break;
		else if(ch==10){
			while((ch=fgetc(fp))!=32)
				if(feof(fp)||ch==10)break;
			while(ch!=10)
				if(b>=ms||(ch=fgetc(fp))==10||feof(fp))break;
				else memory[a][b++]=ch;
			a++;b=0;memory[a][b]=0;
		}else ch=fgetc(fp);
	sf(35);
	fclose(fp);
	return 0;
}
int sm(){
	int a=-1,b=0,c=0;
	char ch;
	ovf(0,35,mp,"w");
	sf(0);
	fprintf(fp,"=====MEMORY=====");
	while(++a<=mm)
		if(memory[a][b=0]!=0){
			fprintf(fp,"\n%d ",c++);
			while(memory[a][b]!=0)
				if(b>=ms)break;
				else fputc(memory[a][b++],fp);
		}
	sf(35);
	fclose(fp);
	return 0;
}
int dfs(int s,int l,char *t){
	return fs(l,s,max,0,output,t);
}
int dga(int a,int l,int v,int *t){
	return gna(v,l,a,max,output,t);
}
int exec(int a){
	int b=0,c=0,out[1]={0};
	rm();
	if((a=dfs(a,max,"[cmd "))>0)
		if(dfs(b=a,2,"am ")>0){
			if((b=dga(b+=3,2,0,&out)+1)>0)
				if(out[0]>mm)b=-1;
				else while(b>0){
					if(b>ms||output[b]==0)b=-1;
					else if(output[b]==93)break;
					else if(output[b]==92)
						if(output[++b+1]==93)b++;memory[out[0]][c++]=output[b++];memory[out[0]][c]=0;
				}
		}else if(dfs(b,2,"dm ")>0)
			if((b=dga(b+=3,2,0,&out))>0)
				if(out[0]>mm)b=-1;
				else memory[out[0]][0]=0;
	osfc(0,109,35,clp);
	if(b<0)return a; 
	sm();
	return b;
}
int main(){
	int a=0;
	for(a=0;a<max;a++)output[a]=0;
	for(a=0;a<mm;a++)
		for(int b=0;b<ms;b++)memory[a][b]=0;a=0;
	while(1)
		if(ovr(a=0,35,0,max,35,0,op,&output)==0)
			while(ovfc(1,0,op)==0)
				if(a<0||a>max||output[a]==0)break;
				else if(ovfc(0,109,clp)==0)a=exec(a);
}